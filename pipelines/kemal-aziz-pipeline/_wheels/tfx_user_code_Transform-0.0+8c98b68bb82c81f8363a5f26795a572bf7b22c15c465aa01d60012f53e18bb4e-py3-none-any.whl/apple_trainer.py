import tensorflow as tf
import tensorflow_transform as tft
from tensorflow.keras import layers, callbacks
from tfx.components.trainer.fn_args_utils import FnArgs
from apple_transform import NUMERIC_FEATURES, LABEL_KEY, transformed_name

def _input_fn(file_pattern, tf_transform_output, batch_size=64):
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=tf_transform_output.transformed_feature_spec(),
        reader=lambda filenames: tf.data.TFRecordDataset(filenames, compression_type="GZIP"),
        label_key=transformed_name(LABEL_KEY)
    )
    return dataset

def _build_keras_model(hparams):
    inputs = {transformed_name(f): layers.Input(shape=(1,), name=transformed_name(f)) 
              for f in NUMERIC_FEATURES}
    
    x = layers.concatenate(list(inputs.values()))
    x = layers.BatchNormalization()(x)
    
    for i in range(hparams['num_layers']):
        x = layers.Dense(hparams[f'units_{i}'], activation='relu')(x)
        x = layers.BatchNormalization()(x)
        x = layers.Dropout(hparams['dropout'])(x)
    
    output = layers.Dense(1, activation='sigmoid')(x)
    
    model = tf.keras.Model(inputs=inputs, outputs=output)
    
    model.compile(
        optimizer=tf.keras.optimizers.Adam(hparams['learning_rate']),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.Precision(name='precision'), 
                 tf.keras.metrics.Recall(name='recall')]
    )
    return model

def run_fn(fn_args: FnArgs):
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_output)
    
    train_dataset = _input_fn(fn_args.train_files, tf_transform_output)
    eval_dataset = _input_fn(fn_args.eval_files, tf_transform_output)
    
    hparams = fn_args.hyperparameters['values']
    
    model = _build_keras_model(hparams)
    
    callbacks = [
        callbacks.EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True
        ),
        callbacks.ReduceLROnPlateau(
            monitor='val_accuracy',
            factor=0.5,
            patience=3
        )
    ]
    
    history = model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps,
        epochs=50,
        callbacks=callbacks
    )
    
    # Simpan model dalam format SavedModel
    model.save(fn_args.serving_model_dir, save_format='tf')
    
    # Simpan metrik evaluasi
    eval_result = model.evaluate(eval_dataset)
    with open(fn_args.serving_model_dir + '/metrics.txt', 'w') as f:
        f.write(f'Accuracy: {eval_result[1]}\n')
        f.write(f'Precision: {eval_result[2]}\n')
        f.write(f'Recall: {eval_result[3]}\n')