import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness', 
    'Acidity'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Handle label
    quality = tf.strings.lower(tf.strings.strip(inputs[LABEL_KEY]))
    quality = tf.where(tf.equal(quality, 'good'), 1, 0)
    outputs[transformed_name(LABEL_KEY)] = tf.cast(quality, tf.int64)
    
    # Handle numeric features
    for feature in NUMERIC_FEATURES:
        # Konversi ke float dan isi missing values
        value = tf.cast(inputs[feature], tf.float32)
        mean_value = tft.mean(value)
        value = tf.where(tf.math.is_nan(value), mean_value, value)
        outputs[transformed_name(feature)] = value
        
    return outputs