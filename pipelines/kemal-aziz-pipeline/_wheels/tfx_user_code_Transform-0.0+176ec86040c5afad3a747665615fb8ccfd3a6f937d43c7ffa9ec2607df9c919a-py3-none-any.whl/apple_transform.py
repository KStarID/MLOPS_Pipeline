import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Tangani fitur numerik
    for feature in NUMERIC_FEATURES:
        # Pastikan input adalah dense tensor
        if isinstance(inputs[feature], tf.sparse.SparseTensor):
            dense_tensor = tf.sparse.to_dense(inputs[feature])
        else:
            dense_tensor = inputs[feature]
        
        # Konversi ke float dan normalisasi
        float_tensor = tf.cast(dense_tensor, tf.float32)
        outputs[transformed_name(feature)] = tft.scale_to_z_score(float_tensor)
    
    # Tangani Acidity secara khusus (karena mungkin string)
    if isinstance(inputs['Acidity'], tf.sparse.SparseTensor):
        acidity_dense = tf.sparse.to_dense(inputs['Acidity'], default_value='0')
    else:
        acidity_dense = inputs['Acidity']
    
    # Konversi string ke float
    def convert_to_float(x):
        return tf.strings.to_number(x, out_type=tf.float32)
    
    acidity_float = tft.apply_function(convert_to_float, acidity_dense)
    outputs[transformed_name('Acidity')] = tft.scale_to_z_score(acidity_float)
    
    # Tangani label Quality
    if isinstance(inputs[LABEL_KEY], tf.sparse.SparseTensor):
        quality_dense = tf.sparse.to_dense(inputs[LABEL_KEY], default_value='bad')
    else:
        quality_dense = inputs[LABEL_KEY]
    
    # Fungsi untuk mengkonversi label ke integer
    def convert_label(x):
        return tf.cast(tf.equal(x, 'good'), tf.int64)
    
    outputs[transformed_name(LABEL_KEY)] = tft.apply_function(convert_label, quality_dense)
    
    return outputs