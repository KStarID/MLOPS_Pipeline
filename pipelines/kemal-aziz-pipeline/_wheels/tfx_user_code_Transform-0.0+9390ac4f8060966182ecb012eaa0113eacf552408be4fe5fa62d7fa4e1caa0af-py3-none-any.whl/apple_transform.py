import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Normalisasi fitur numerik
    for feature in NUMERIC_FEATURES:
        outputs[transformed_name(feature)] = tft.scale_to_z_score(inputs[feature])
    
    # Tangani Acidity
    # Konversi ke float terlebih dahulu
    outputs[transformed_name('Acidity')] = tft.scale_to_z_score(
        tf.cast(inputs['Acidity'], tf.float32)
    )
    
    # Konversi label ke vocabulary index
    outputs[transformed_name(LABEL_KEY)] = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY],
        top_k=2,
        vocab_filename=transformed_name(LABEL_KEY)
    )
    
    return outputs