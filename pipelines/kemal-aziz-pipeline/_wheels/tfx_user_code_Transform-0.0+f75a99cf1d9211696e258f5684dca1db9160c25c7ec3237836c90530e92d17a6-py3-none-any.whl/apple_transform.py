import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    """Preprocessing function dengan TF 1.x compatibility mode."""
    outputs = {}
    
    # Gunakan TF 1.x compatibility mode
    with tf.compat.v1.name_scope('transform'):
        # Proses fitur numerik
        for feature in NUMERIC_FEATURES:
            outputs[transformed_name(feature)] = tf.cast(inputs[feature], tf.float32)
        
        # Proses Acidity
        # Konversi string ke float
        acidity_values = tf.strings.to_number(
            tf.strings.regex_replace(inputs['Acidity'], '[^0-9.-]', '0'),
            out_type=tf.float32
        )
        outputs[transformed_name('Acidity')] = acidity_values
        
        # Proses Quality
        # Konversi ke 0/1 dengan vocabulary
        outputs[transformed_name(LABEL_KEY)] = tf.where(
            tf.equal(inputs[LABEL_KEY], 'good'),
            tf.ones_like(inputs[LABEL_KEY], dtype=tf.int64),
            tf.zeros_like(inputs[LABEL_KEY], dtype=tf.int64)
        )
    
    return outputs