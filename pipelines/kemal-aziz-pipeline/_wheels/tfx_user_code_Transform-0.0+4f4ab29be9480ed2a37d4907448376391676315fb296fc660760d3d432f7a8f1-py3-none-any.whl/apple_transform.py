import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
# Acidity sebagai fitur string yang perlu dikonversi
STRING_FEATURES = ['Acidity']
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Normalisasi fitur numerik
    for feature in NUMERIC_FEATURES:
        outputs[transformed_name(feature)] = tft.scale_to_z_score(inputs[feature])
    
    # Konversi Acidity dari string ke float dan normalisasi
    acidity_float = tf.strings.to_number(
        tf.sparse.to_dense(inputs['Acidity'], default_value='0'),
        out_type=tf.float32
    )
    outputs[transformed_name('Acidity')] = tft.scale_to_z_score(acidity_float)
    
    # Konversi label string ke integer (bad=0, good=1)
    # Menggunakan tft.string_to_int yang lebih langsung untuk kasus binary
    quality_int = tft.string_to_int(
        inputs[LABEL_KEY], 
        vocab=['bad', 'good']  # Pastikan 'bad' indeks 0, 'good' indeks 1
    )
    
    # Outputkan langsung hasil konversi
    outputs[transformed_name(LABEL_KEY)] = quality_int
    
    return outputs