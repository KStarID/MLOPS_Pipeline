import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
# Acidity sebagai fitur string yang perlu dikonversi
STRING_FEATURES = ['Acidity']
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Normalisasi fitur numerik
    for feature in NUMERIC_FEATURES:
        outputs[transformed_name(feature)] = tft.scale_to_z_score(inputs[feature])
    
    # Konversi Acidity dari string ke float dan normalisasi
    acidity_float = tf.strings.to_number(
        tf.sparse.to_dense(inputs['Acidity'], default_value='0'),
        out_type=tf.float32
    )
    outputs[transformed_name('Acidity')] = tft.scale_to_z_score(acidity_float)
    
    # Konversi label ke binary (0/1)
    # Gunakan vocabulary untuk label
    quality_vocab = tft.compute_and_apply_vocabulary(
        inputs[LABEL_KEY], 
        vocab_filename=transformed_name(LABEL_KEY)
    )
    
    # Konversi indeks vocabulary ke binary (0/1)
    # 'good' biasanya akan menjadi indeks 1 (karena secara alfabetis setelah 'bad')
    outputs[transformed_name(LABEL_KEY)] = tf.cast(
        tf.where(tf.equal(quality_vocab, 1), 1, 0),
        tf.int64
    )
    
    return outputs