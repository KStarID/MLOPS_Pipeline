import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def _fill_in_missing(x):
    """Replace missing values with a default value."""
    return tf.where(tf.math.is_nan(x), tf.zeros_like(x), x)

def _convert_string_to_float(x):
    """Convert string tensor to float."""
    # Handle sparse tensor if needed
    if isinstance(x, tf.sparse.SparseTensor):
        x = tf.sparse.to_dense(x, default_value="0")
    # Convert string to float
    return tf.strings.to_number(x, out_type=tf.float32)

def _convert_quality_to_int(x):
    """Convert quality label to binary int."""
    # Handle sparse tensor if needed
    if isinstance(x, tf.sparse.SparseTensor):
        x = tf.sparse.to_dense(x, default_value="bad")
    # Convert to int (1 for 'good', 0 for anything else)
    return tf.cast(tf.equal(x, "good"), tf.int64)

def preprocessing_fn(inputs):
    outputs = {}
    
    # Process numeric features
    for feature in NUMERIC_FEATURES:
        # Convert to float and handle missing values
        outputs[transformed_name(feature)] = tft.scale_to_z_score(
            tft.apply_function(_fill_in_missing, tf.cast(inputs[feature], tf.float32))
        )
    
    # Process Acidity feature (string to float)
    outputs[transformed_name('Acidity')] = tft.scale_to_z_score(
        tft.apply_function(_convert_string_to_float, inputs['Acidity'])
    )
    
    # Process Quality label (string to int)
    outputs[transformed_name(LABEL_KEY)] = tft.apply_function(
        _convert_quality_to_int, inputs[LABEL_KEY]
    )
    
    return outputs