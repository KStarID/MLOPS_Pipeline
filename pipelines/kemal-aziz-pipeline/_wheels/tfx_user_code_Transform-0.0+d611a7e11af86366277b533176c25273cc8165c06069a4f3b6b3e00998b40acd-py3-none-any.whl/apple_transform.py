import tensorflow as tf
import tensorflow_transform as tft

# Fitur numerik dari dataset Apple Quality
NUMERIC_FEATURES = [
    'Size', 'Weight', 'Sweetness', 
    'Crunchiness', 'Juiciness', 'Ripeness', 
    'Acidity'
]
LABEL_KEY = 'Quality'

def transformed_name(key):
    return f"{key}_xf"

def preprocessing_fn(inputs):
    outputs = {}
    
    # Konversi label ke integer
    quality = tf.strings.strip(inputs[LABEL_KEY])  # Bersihkan whitespace
    quality = tf.where(tf.equal(quality, 'good'), 1, 0)
    outputs[transformed_name(LABEL_KEY)] = quality
    
    # Pastikan semua feature numerik dikonversi ke float
    for feature in NUMERIC_FEATURES:
        # Konversi ke float jika perlu
        value = tf.cast(inputs[feature], tf.float32)
        # Handle missing values (contoh: isi dengan mean)
        value = tft.mean(value, axis=0) * tf.ones_like(value)
        outputs[transformed_name(feature)] = value
        
    return outputs